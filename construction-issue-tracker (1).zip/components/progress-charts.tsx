"use client"

import { useEffect, useRef, useState } from "react"
import { Activity, BarChart3, Heart, Footprints } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"

interface ChartProps {
  detailed?: boolean
}

export function ProgressCharts({ detailed = false }: ChartProps) {
  const [activeTab, setActiveTab] = useState("steps")
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set dimensions
    const width = canvas.width
    const height = canvas.height
    const padding = 40
    const chartWidth = width - padding * 2
    const chartHeight = height - padding * 2

    // Draw axes
    ctx.beginPath()
    ctx.strokeStyle = "#e5e7eb" // gray-200
    ctx.moveTo(padding, padding)
    ctx.lineTo(padding, height - padding)
    ctx.lineTo(width - padding, height - padding)
    ctx.stroke()

    // Generate data based on active tab
    let data: number[] = []
    const days = detailed ? 30 : 7
    const labels = Array.from({ length: days }, (_, i) => i + 1)

    switch (activeTab) {
      case "steps":
        data = Array.from({ length: days }, () => Math.floor(Math.random() * 5000) + 5000)
        break
      case "heart":
        data = Array.from({ length: days }, () => Math.floor(Math.random() * 20) + 60)
        break
      case "calories":
        data = Array.from({ length: days }, () => Math.floor(Math.random() * 1000) + 1000)
        break
      case "workouts":
        data = Array.from({ length: days }, () => Math.floor(Math.random() * 120) + 30)
        break
    }

    // Calculate scales
    const maxValue = Math.max(...data) * 1.1
    const xScale = chartWidth / (data.length - 1)
    const yScale = chartHeight / maxValue

    // Draw y-axis labels
    ctx.fillStyle = "#6b7280" // gray-500
    ctx.font = "10px sans-serif"
    ctx.textAlign = "right"
    ctx.textBaseline = "middle"

    const yLabelCount = 5
    for (let i = 0; i <= yLabelCount; i++) {
      const value = Math.round((maxValue * i) / yLabelCount)
      const y = height - padding - value * yScale
      ctx.fillText(value.toString(), padding - 5, y)

      // Draw horizontal grid line
      ctx.beginPath()
      ctx.strokeStyle = "#f3f4f6" // gray-100
      ctx.moveTo(padding, y)
      ctx.lineTo(width - padding, y)
      ctx.stroke()
    }

    // Draw x-axis labels
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    const labelInterval = detailed ? 5 : 1
    labels.forEach((label, i) => {
      if (i % labelInterval === 0 || i === labels.length - 1) {
        const x = padding + i * xScale
        ctx.fillText(label.toString(), x, height - padding + 5)
      }
    })

    // Draw line
    ctx.beginPath()
    ctx.strokeStyle = "#f97316" // orange-500
    ctx.lineWidth = 2
    data.forEach((value, i) => {
      const x = padding + i * xScale
      const y = height - padding - value * yScale
      if (i === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    })
    ctx.stroke()

    // Draw points
    data.forEach((value, i) => {
      const x = padding + i * xScale
      const y = height - padding - value * yScale
      ctx.beginPath()
      ctx.fillStyle = "#ffffff"
      ctx.arc(x, y, 4, 0, Math.PI * 2)
      ctx.fill()
      ctx.beginPath()
      ctx.fillStyle = "#f97316" // orange-500
      ctx.arc(x, y, 3, 0, Math.PI * 2)
      ctx.fill()
    })

    // Draw area under the line
    ctx.beginPath()
    ctx.fillStyle = "rgba(249, 115, 22, 0.1)" // orange-500 with opacity
    data.forEach((value, i) => {
      const x = padding + i * xScale
      const y = height - padding - value * yScale
      if (i === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    })
    ctx.lineTo(padding + (data.length - 1) * xScale, height - padding)
    ctx.lineTo(padding, height - padding)
    ctx.closePath()
    ctx.fill()
  }, [activeTab, detailed])

  return (
    <div className="h-full w-full">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="steps" className="flex items-center gap-1">
              <Footprints className="h-4 w-4" />
              <span className={cn(detailed ? "inline" : "hidden sm:inline")}>Steps</span>
            </TabsTrigger>
            <TabsTrigger value="heart" className="flex items-center gap-1">
              <Heart className="h-4 w-4" />
              <span className={cn(detailed ? "inline" : "hidden sm:inline")}>Heart Rate</span>
            </TabsTrigger>
            <TabsTrigger value="calories" className="flex items-center gap-1">
              <Activity className="h-4 w-4" />
              <span className={cn(detailed ? "inline" : "hidden sm:inline")}>Calories</span>
            </TabsTrigger>
            <TabsTrigger value="workouts" className="flex items-center gap-1">
              <BarChart3 className="h-4 w-4" />
              <span className={cn(detailed ? "inline" : "hidden sm:inline")}>Workout Time</span>
            </TabsTrigger>
          </TabsList>
          {detailed && (
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                Week
              </Button>
              <Button variant="outline" size="sm">
                Month
              </Button>
              <Button variant="outline" size="sm">
                Year
              </Button>
            </div>
          )}
        </div>
        <div className="h-[calc(100%-40px)] w-full">
          <canvas ref={canvasRef} width={800} height={detailed ? 400 : 300} className="h-full w-full"></canvas>
        </div>
      </Tabs>
    </div>
  )
}
