"use client"

import { useState } from "react"
import {
  Bike,
  Dumbbell,
  Edit,
  FishIcon as Swim,
  MoreHorizontal,
  MonitorIcon as Running,
  SpaceIcon as Yoga,
  Trash2,
} from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useToast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"

interface WorkoutHistoryProps {
  searchQuery?: string
}

export function WorkoutHistory({ searchQuery = "" }: WorkoutHistoryProps) {
  const { toast } = useToast()
  const [workouts, setWorkouts] = useState([
    {
      id: 1,
      type: "Strength",
      name: "Upper Body Workout",
      duration: "45 min",
      calories: 320,
      date: "Today",
      icon: Dumbbell,
      color: "text-purple-500",
    },
    {
      id: 2,
      type: "Cardio",
      name: "Morning Run",
      duration: "30 min",
      calories: 280,
      date: "Yesterday",
      icon: Running,
      color: "text-green-500",
    },
    {
      id: 3,
      type: "Cycling",
      name: "Interval Cycling",
      duration: "50 min",
      calories: 450,
      date: "2 days ago",
      icon: Bike,
      color: "text-blue-500",
    },
    {
      id: 4,
      type: "Swimming",
      name: "Lap Swimming",
      duration: "40 min",
      calories: 380,
      date: "3 days ago",
      icon: Swim,
      color: "text-cyan-500",
    },
    {
      id: 5,
      type: "Flexibility",
      name: "Yoga Session",
      duration: "60 min",
      calories: 220,
      date: "4 days ago",
      icon: Yoga,
      color: "text-amber-500",
    },
    {
      id: 6,
      type: "Strength",
      name: "Lower Body Workout",
      duration: "50 min",
      calories: 350,
      date: "5 days ago",
      icon: Dumbbell,
      color: "text-purple-500",
    },
    {
      id: 7,
      type: "Cardio",
      name: "HIIT Session",
      duration: "25 min",
      calories: 300,
      date: "6 days ago",
      icon: Running,
      color: "text-green-500",
    },
    {
      id: 8,
      type: "Cycling",
      name: "Outdoor Cycling",
      duration: "75 min",
      calories: 520,
      date: "1 week ago",
      icon: Bike,
      color: "text-blue-500",
    },
  ])

  const handleDeleteWorkout = (id: number) => {
    setWorkouts(workouts.filter((workout) => workout.id !== id))
    toast({
      title: "Workout deleted",
      description: "The workout has been removed from your history.",
    })
  }

  const filteredWorkouts = workouts.filter(
    (workout) =>
      workout.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      workout.type.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="space-y-4">
      {filteredWorkouts.length === 0 ? (
        <div className="flex h-32 items-center justify-center rounded-md border border-dashed">
          <p className="text-center text-muted-foreground">No workouts found</p>
        </div>
      ) : (
        filteredWorkouts.map((workout) => (
          <div key={workout.id} className="flex items-start gap-4">
            <div
              className={cn(
                "flex h-10 w-10 items-center justify-center rounded-full bg-muted",
                workout.color.replace("text", "bg").replace("500", "100"),
              )}
            >
              <workout.icon className={cn("h-5 w-5", workout.color)} />
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between">
                <div className="font-medium">{workout.name}</div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">Open menu</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <Edit className="mr-2 h-4 w-4" />
                      <span>Edit</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => handleDeleteWorkout(workout.id)}>
                      <Trash2 className="mr-2 h-4 w-4" />
                      <span>Delete</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline">{workout.type}</Badge>
                <span className="text-sm text-muted-foreground">
                  {workout.duration} • {workout.calories} calories
                </span>
              </div>
              <div className="text-xs text-muted-foreground">{workout.date}</div>
            </div>
          </div>
        ))
      )}
    </div>
  )
}
