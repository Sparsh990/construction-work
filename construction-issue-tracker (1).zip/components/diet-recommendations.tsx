import { Apple, Beef, Egg, Fish, Salad } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"

interface DietRecommendationsProps {
  detailed?: boolean
}

export function DietRecommendations({ detailed = false }: DietRecommendationsProps) {
  const macros = [
    { name: "Protein", current: 120, target: 150, unit: "g", color: "bg-blue-500" },
    { name: "Carbs", current: 180, target: 200, unit: "g", color: "bg-amber-500" },
    { name: "Fat", current: 55, target: 65, unit: "g", color: "bg-green-500" },
  ]

  const recommendations = [
    {
      id: 1,
      title: "Increase protein intake",
      description: "Based on your workout intensity, we recommend adding more lean protein to your diet.",
      icon: Beef,
      color: "text-red-500",
    },
    {
      id: 2,
      title: "Add more leafy greens",
      description: "Your micronutrient profile shows you could benefit from more vitamins A and K.",
      icon: Salad,
      color: "text-green-500",
    },
    {
      id: 3,
      title: "Consider omega-3 supplements",
      description: "Your heart rate variability could improve with more omega-3 fatty acids.",
      icon: Fish,
      color: "text-blue-500",
    },
  ]

  const mealPlan = [
    {
      meal: "Breakfast",
      foods: [
        { name: "Egg white omelette", icon: Egg, color: "text-yellow-500" },
        { name: "Whole grain toast", icon: Apple, color: "text-amber-700" },
        { name: "Greek yogurt with berries", icon: Apple, color: "text-purple-500" },
      ],
    },
    {
      meal: "Lunch",
      foods: [
        { name: "Grilled chicken salad", icon: Salad, color: "text-green-500" },
        { name: "Quinoa", icon: Apple, color: "text-amber-500" },
        { name: "Avocado", icon: Apple, color: "text-green-700" },
      ],
    },
    {
      meal: "Dinner",
      foods: [
        { name: "Baked salmon", icon: Fish, color: "text-pink-500" },
        { name: "Steamed vegetables", icon: Salad, color: "text-green-500" },
        { name: "Sweet potato", icon: Apple, color: "text-orange-500" },
      ],
    },
    {
      meal: "Snacks",
      foods: [
        { name: "Protein shake", icon: Apple, color: "text-blue-500" },
        { name: "Mixed nuts", icon: Apple, color: "text-amber-700" },
        { name: "Apple with almond butter", icon: Apple, color: "text-red-500" },
      ],
    },
  ]

  return (
    <div className="space-y-4">
      {!detailed ? (
        <>
          <div className="space-y-2">
            <div className="text-sm font-medium">Today's Macronutrients</div>
            <div className="grid gap-2">
              {macros.map((macro) => (
                <div key={macro.name} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span>{macro.name}</span>
                    <span>
                      {macro.current}/{macro.target} {macro.unit}
                    </span>
                  </div>
                  <Progress value={(macro.current / macro.target) * 100} className={cn("h-2", macro.color)} />
                </div>
              ))}
            </div>
          </div>
          <Separator />
          <div className="space-y-3">
            <div className="text-sm font-medium">Recommendations</div>
            {recommendations.slice(0, 2).map((rec) => (
              <div key={rec.id} className="flex items-start gap-3">
                <div
                  className={cn(
                    "flex h-8 w-8 items-center justify-center rounded-full bg-muted",
                    rec.color.replace("text", "bg").replace("500", "100"),
                  )}
                >
                  <rec.icon className={cn("h-4 w-4", rec.color)} />
                </div>
                <div>
                  <div className="text-sm font-medium">{rec.title}</div>
                  <div className="text-xs text-muted-foreground">{rec.description}</div>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <>
          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-3">
              {macros.map((macro) => (
                <Card key={macro.name}>
                  <CardContent className="p-4">
                    <div className="text-center">
                      <div className="text-lg font-bold">{macro.name}</div>
                      <div className="mt-2 text-3xl font-bold">
                        {macro.current}
                        <span className="text-base text-muted-foreground">
                          /{macro.target}
                          {macro.unit}
                        </span>
                      </div>
                      <Progress value={(macro.current / macro.target) * 100} className={cn("mt-2 h-2", macro.color)} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium">Personalized Recommendations</h3>
              <div className="grid gap-4 md:grid-cols-3">
                {recommendations.map((rec) => (
                  <Card key={rec.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div
                          className={cn(
                            "flex h-10 w-10 items-center justify-center rounded-full bg-muted",
                            rec.color.replace("text", "bg").replace("500", "100"),
                          )}
                        >
                          <rec.icon className={cn("h-5 w-5", rec.color)} />
                        </div>
                        <div>
                          <div className="font-medium">{rec.title}</div>
                          <div className="text-sm text-muted-foreground">{rec.description}</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium">Recommended Meal Plan</h3>
              <div className="grid gap-4 md:grid-cols-2">
                {mealPlan.map((meal) => (
                  <Card key={meal.meal}>
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="font-medium">{meal.meal}</div>
                        <div className="space-y-2">
                          {meal.foods.map((food, i) => (
                            <div key={i} className="flex items-center gap-2">
                              <food.icon className={cn("h-4 w-4", food.color)} />
                              <span className="text-sm">{food.name}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
