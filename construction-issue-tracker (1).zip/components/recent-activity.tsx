import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function RecentActivity() {
  const activities = [
    {
      id: 1,
      user: "Sarah Johnson",
      role: "Site Manager",
      action: "updated status to In Progress",
      issue: "Lack of drinking water in east wing work area",
      time: "10 minutes ago",
    },
    {
      id: 2,
      user: "David Chen",
      role: "HR Manager",
      action: "assigned to HR Department",
      issue: "Excessive workload with insufficient breaks",
      time: "30 minutes ago",
    },
    {
      id: 3,
      user: "Maria Rodriguez",
      role: "Construction Worker",
      action: "reported new issue",
      issue: "Wage payment delayed for contract workers",
      time: "1 hour ago",
    },
    {
      id: 4,
      user: "James Wilson",
      role: "Safety Officer",
      action: "added comment to",
      issue: "Missing safety railings on 3rd floor balcony",
      time: "2 hours ago",
    },
    {
      id: 5,
      user: "Alex Johnson",
      role: "Contractor",
      action: "marked as resolved",
      issue: "Excessive heat in work area due to HVAC failure",
      time: "3 hours ago",
    },
  ]

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-start gap-4">
          <Avatar className="h-10 w-10">
            <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={activity.user} />
            <AvatarFallback>
              {activity.user
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </AvatarFallback>
          </Avatar>
          <div className="space-y-1">
            <p className="text-sm">
              <span className="font-medium text-blue-800">{activity.user}</span>
              <span className="text-muted-foreground"> {activity.action} </span>
              <span className="font-medium">"{activity.issue}"</span>
            </p>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">{activity.role}</span>
              <span className="text-xs text-muted-foreground">•</span>
              <span className="text-xs text-muted-foreground">{activity.time}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
