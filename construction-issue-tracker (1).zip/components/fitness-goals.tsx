import { CheckCircle2 } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

const goals = [
  {
    id: 1,
    name: "Weight Goal",
    target: "Lose 5kg",
    current: "3.2kg lost",
    progress: 64,
    dueDate: "2 weeks left",
    status: "on-track",
  },
  {
    id: 2,
    name: "Weekly Workouts",
    target: "5 workouts",
    current: "4 completed",
    progress: 80,
    dueDate: "3 days left",
    status: "on-track",
  },
  {
    id: 3,
    name: "Daily Steps",
    target: "10,000 steps",
    current: "8,249 steps",
    progress: 82,
    dueDate: "Today",
    status: "on-track",
  },
  {
    id: 4,
    name: "Water Intake",
    target: "2.5L daily",
    current: "1.8L consumed",
    progress: 72,
    dueDate: "Today",
    status: "at-risk",
  },
]

export function FitnessGoals() {
  return (
    <div className="space-y-4">
      {goals.map((goal) => (
        <div key={goal.id} className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="font-medium">{goal.name}</div>
            <Badge
              variant="outline"
              className={
                goal.status === "on-track"
                  ? "border-green-500 text-green-500"
                  : goal.status === "at-risk"
                    ? "border-amber-500 text-amber-500"
                    : "border-red-500 text-red-500"
              }
            >
              {goal.status === "on-track" ? (
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3" /> On Track
                </span>
              ) : goal.status === "at-risk" ? (
                "At Risk"
              ) : (
                "Off Track"
              )}
            </Badge>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span>
              Target: {goal.target} • Current: {goal.current}
            </span>
            <span className="text-muted-foreground">{goal.dueDate}</span>
          </div>
          <Progress value={goal.progress} className="h-2" />
        </div>
      ))}
    </div>
  )
}
