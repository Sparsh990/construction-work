import { Dumbbell, MonitorIcon as Running, Bike, FishIcon as Swim, SpaceIcon as Yoga } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

const workouts = [
  {
    id: 1,
    type: "Strength",
    name: "Upper Body Workout",
    duration: "45 min",
    calories: 320,
    date: "Today",
    icon: Dumbbell,
    color: "text-purple-500",
  },
  {
    id: 2,
    type: "Cardio",
    name: "Morning Run",
    duration: "30 min",
    calories: 280,
    date: "Yesterday",
    icon: Running,
    color: "text-green-500",
  },
  {
    id: 3,
    type: "Cycling",
    name: "Interval Cycling",
    duration: "50 min",
    calories: 450,
    date: "2 days ago",
    icon: Bike,
    color: "text-blue-500",
  },
  {
    id: 4,
    type: "Swimming",
    name: "Lap Swimming",
    duration: "40 min",
    calories: 380,
    date: "3 days ago",
    icon: Swim,
    color: "text-cyan-500",
  },
  {
    id: 5,
    type: "Flexibility",
    name: "Yoga Session",
    duration: "60 min",
    calories: 220,
    date: "4 days ago",
    icon: Yoga,
    color: "text-amber-500",
  },
]

export function RecentWorkouts() {
  return (
    <div className="space-y-4">
      {workouts.map((workout) => (
        <div key={workout.id} className="flex items-start gap-4">
          <div
            className={cn(
              "flex h-10 w-10 items-center justify-center rounded-full bg-muted",
              workout.color.replace("text", "bg").replace("500", "100"),
            )}
          >
            <workout.icon className={cn("h-5 w-5", workout.color)} />
          </div>
          <div className="flex-1 space-y-1">
            <div className="flex items-center justify-between">
              <div className="font-medium">{workout.name}</div>
              <Badge variant="outline">{workout.type}</Badge>
            </div>
            <div className="text-sm text-muted-foreground">
              {workout.duration} • {workout.calories} calories
            </div>
            <div className="text-xs text-muted-foreground">{workout.date}</div>
          </div>
        </div>
      ))}
    </div>
  )
}
