import Link from "next/link"
import { AlertTriangle, CheckCircle2, Clock } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"

type IssueStatus = "open" | "in-progress" | "resolved"

interface Issue {
  id: string
  title: string
  location: string
  category: string
  priority: "Low" | "Medium" | "High" | "Critical"
  status: IssueStatus
  reportedBy: string
  reportedAt: string
  assignedTo: string
}

interface IssuesListProps {
  filter: IssueStatus | "all"
}

export function IssuesList({ filter }: IssuesListProps) {
  // Mock data for issues
  const issues: Issue[] = [
    {
      id: "1234",
      title: "Lack of drinking water in east wing work area",
      location: "East Wing, 2nd Floor",
      category: "Water Supply Problem",
      priority: "High",
      status: "in-progress",
      reportedBy: "John Carpenter",
      reportedAt: "2 days ago",
      assignedTo: "Site Manager",
    },
    {
      id: "1235",
      title: "Excessive workload with insufficient breaks",
      location: "North Tower, All Floors",
      category: "Workload",
      priority: "Critical",
      status: "open",
      reportedBy: "Maria Rodriguez",
      reportedAt: "1 day ago",
      assignedTo: "HR Department",
    },
    {
      id: "1236",
      title: "Wage payment delayed for contract workers",
      location: "Company-wide",
      category: "Wages",
      priority: "High",
      status: "open",
      reportedBy: "David Kim",
      reportedAt: "3 days ago",
      assignedTo: "Contractor",
    },
    {
      id: "1237",
      title: "Inadequate restroom facilities for workers",
      location: "South Entrance",
      category: "Facilities",
      priority: "Medium",
      status: "in-progress",
      reportedBy: "Alex Johnson",
      reportedAt: "4 days ago",
      assignedTo: "Site Manager",
    },
    {
      id: "1238",
      title: "Missing safety railings on 3rd floor balcony",
      location: "West Wing, 3rd Floor",
      category: "Safety Hazard",
      priority: "Critical",
      status: "resolved",
      reportedBy: "Sarah Williams",
      reportedAt: "5 days ago",
      assignedTo: "Safety Team",
    },
    {
      id: "1239",
      title: "Excessive heat in work area due to HVAC failure",
      location: "Central Building, 1st Floor",
      category: "Equipment Malfunction",
      priority: "Medium",
      status: "resolved",
      reportedBy: "James Wilson",
      reportedAt: "1 week ago",
      assignedTo: "HVAC Specialists",
    },
  ]

  const filteredIssues = filter === "all" ? issues : issues.filter((issue) => issue.status === filter)

  return (
    <div className="space-y-4">
      {filteredIssues.length === 0 ? (
        <Card className="border-blue-100">
          <CardContent className="flex items-center justify-center p-6">
            <p className="text-center text-muted-foreground">No issues found matching the selected filter.</p>
          </CardContent>
        </Card>
      ) : (
        filteredIssues.map((issue) => (
          <Link href={`/issues/${issue.id}`} key={issue.id}>
            <Card className="border-blue-100 hover:bg-blue-50/50 transition-colors">
              <CardContent className="p-4">
                <div className="grid gap-1 sm:grid-cols-2 md:grid-cols-4">
                  <div className="col-span-2">
                    <div className="flex items-start gap-2">
                      {issue.status === "open" && <AlertTriangle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />}
                      {issue.status === "in-progress" && <Clock className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />}
                      {issue.status === "resolved" && (
                        <CheckCircle2 className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <h3 className="font-medium leading-none text-blue-800">{issue.title}</h3>
                        <p className="text-sm text-muted-foreground mt-1">{issue.location}</p>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-1 sm:grid-cols-1 md:grid-cols-2">
                    <div>
                      <p className="text-xs text-muted-foreground">Category</p>
                      <p className="text-sm">{issue.category}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Priority</p>
                      <Badge
                        variant="outline"
                        className={
                          issue.priority === "Critical"
                            ? "border-red-500 text-red-500"
                            : issue.priority === "High"
                              ? "border-orange-500 text-orange-500"
                              : issue.priority === "Medium"
                                ? "border-amber-500 text-amber-500"
                                : "border-green-500 text-green-500"
                        }
                      >
                        {issue.priority}
                      </Badge>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-1 sm:grid-cols-1 md:grid-cols-2">
                    <div>
                      <p className="text-xs text-muted-foreground">Reported</p>
                      <p className="text-sm">{issue.reportedAt}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Assigned To</p>
                      <p className="text-sm">{issue.assignedTo}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))
      )}
    </div>
  )
}
