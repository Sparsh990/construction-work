import { cn } from "@/lib/utils"
import { Activity, Dumbbell, Heart, Footprints } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function FitnessMetrics() {
  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Steps</CardTitle>
          <Footprints className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">8,249</div>
          <p className="text-xs text-muted-foreground">
            <span className="text-green-500">+12%</span> from yesterday
          </p>
          <div className="mt-3 h-1 w-full rounded-full bg-muted">
            <div className="h-1 w-[68%] rounded-full bg-orange-500" />
          </div>
          <p className="mt-1 text-xs text-muted-foreground">68% of daily goal</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Heart Rate</CardTitle>
          <Heart className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">72 BPM</div>
          <p className="text-xs text-muted-foreground">Resting rate</p>
          <div className="mt-3 grid grid-cols-7 gap-1">
            {[65, 68, 72, 80, 76, 72, 72].map((rate, i) => (
              <div key={i} className="flex flex-col items-center">
                <div
                  className="h-10 w-2 rounded-full bg-orange-500"
                  style={{ height: `${(rate / 100) * 40 + 10}px` }}
                />
                <span className="mt-1 text-[10px] text-muted-foreground">{i + 1}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Calories</CardTitle>
          <Activity className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">1,842</div>
          <p className="text-xs text-muted-foreground">
            <span className="text-green-500">+8%</span> from average
          </p>
          <div className="mt-3 h-1 w-full rounded-full bg-muted">
            <div className="h-1 w-[75%] rounded-full bg-orange-500" />
          </div>
          <p className="mt-1 text-xs text-muted-foreground">75% of daily burn goal</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Workouts</CardTitle>
          <Dumbbell className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">4 / 5</div>
          <p className="text-xs text-muted-foreground">Weekly target</p>
          <div className="mt-3 grid grid-cols-7 gap-1">
            {[1, 1, 0, 1, 1, 0, 0].map((completed, i) => (
              <div
                key={i}
                className={cn(
                  "flex h-7 w-full items-center justify-center rounded-sm text-[10px] font-medium",
                  completed ? "bg-orange-500 text-white" : "bg-muted text-muted-foreground",
                )}
              >
                {["M", "T", "W", "T", "F", "S", "S"][i]}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </>
  )
}
