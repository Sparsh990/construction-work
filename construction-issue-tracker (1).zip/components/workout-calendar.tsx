"use client"

import { useState } from "react"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { Bike, Dumbbell, MonitorIcon as Running, FishIcon as Swim, SpaceIcon as Yoga } from "lucide-react"

export function WorkoutCalendar() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  // Mock workout data
  const workoutDates = [
    { date: new Date(2023, 3, 15), type: "Strength", icon: Dumbbell, color: "text-purple-500" },
    { date: new Date(2023, 3, 16), type: "Cardio", icon: Running, color: "text-green-500" },
    { date: new Date(2023, 3, 18), type: "Cycling", icon: Bike, color: "text-blue-500" },
    { date: new Date(2023, 3, 19), type: "Swimming", icon: Swim, color: "text-cyan-500" },
    { date: new Date(2023, 3, 21), type: "Yoga", icon: Yoga, color: "text-amber-500" },
    { date: new Date(2023, 3, 22), type: "Strength", icon: Dumbbell, color: "text-purple-500" },
    { date: new Date(2023, 3, 24), type: "Cardio", icon: Running, color: "text-green-500" },
    { date: new Date(2023, 3, 26), type: "Cycling", icon: Bike, color: "text-blue-500" },
    { date: new Date(2023, 3, 28), type: "Strength", icon: Dumbbell, color: "text-purple-500" },
    { date: new Date(2023, 3, 30), type: "Yoga", icon: Yoga, color: "text-amber-500" },
    { date: new Date(2023, 4, 2), type: "Cardio", icon: Running, color: "text-green-500" },
    { date: new Date(2023, 4, 3), type: "Strength", icon: Dumbbell, color: "text-purple-500" },
    { date: new Date(2023, 4, 5), type: "Swimming", icon: Swim, color: "text-cyan-500" },
    { date: new Date(2023, 4, 7), type: "Cycling", icon: Bike, color: "text-blue-500" },
    { date: new Date(2023, 4, 9), type: "Strength", icon: Dumbbell, color: "text-purple-500" },
    { date: new Date(2023, 4, 10), type: "Cardio", icon: Running, color: "text-green-500" },
    { date: new Date(2023, 4, 12), type: "Yoga", icon: Yoga, color: "text-amber-500" },
    { date: new Date(2023, 4, 14), type: "Strength", icon: Dumbbell, color: "text-purple-500" },
    { date: new Date(2023, 4, 16), type: "Cycling", icon: Bike, color: "text-blue-500" },
    { date: new Date(2023, 4, 18), type: "Swimming", icon: Swim, color: "text-cyan-500" },
    { date: new Date(2023, 4, 20), type: "Strength", icon: Dumbbell, color: "text-purple-500" },
    { date: new Date(2023, 4, 21), type: "Cardio", icon: Running, color: "text-green-500" },
  ]

  // Find selected date workout
  const selectedWorkout = workoutDates.find((w) => date && w.date.toDateString() === date.toDateString())

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Calendar
        mode="single"
        selected={date}
        onSelect={setDate}
        className="rounded-md border"
        modifiers={{
          workout: workoutDates.map((w) => w.date),
        }}
        modifiersStyles={{
          workout: { fontWeight: "bold", textDecoration: "underline" },
        }}
        components={{
          DayContent: (props) => {
            const workout = workoutDates.find((w) => w.date.toDateString() === props.date.toDateString())

            if (workout) {
              return (
                <div className="relative flex h-full w-full items-center justify-center">
                  {props.date.getDate()}
                  <div
                    className={cn(
                      "absolute -bottom-1 left-1/2 h-1.5 w-1.5 -translate-x-1/2 rounded-full",
                      workout.color.replace("text", "bg"),
                    )}
                  />
                </div>
              )
            }

            return <div className="flex h-full w-full items-center justify-center">{props.date.getDate()}</div>
          },
        }}
      />

      <div>
        {selectedWorkout ? (
          <Card>
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <div
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-full bg-muted",
                    selectedWorkout.color.replace("text", "bg").replace("500", "100"),
                  )}
                >
                  <selectedWorkout.icon className={cn("h-5 w-5", selectedWorkout.color)} />
                </div>
                <div className="space-y-1">
                  <h3 className="font-medium">{selectedWorkout.type} Workout</h3>
                  <p className="text-sm text-muted-foreground">
                    {selectedWorkout.date.toLocaleDateString("en-US", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </p>
                  <div className="mt-4 space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="rounded-md bg-muted p-2 text-center">
                        <div className="text-xs text-muted-foreground">Duration</div>
                        <div className="font-medium">45 min</div>
                      </div>
                      <div className="rounded-md bg-muted p-2 text-center">
                        <div className="text-xs text-muted-foreground">Calories</div>
                        <div className="font-medium">320</div>
                      </div>
                    </div>
                    <div className="rounded-md bg-muted p-2">
                      <div className="text-xs text-muted-foreground">Notes</div>
                      <div className="text-sm">Completed full routine with increased weights on bench press.</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="flex h-full items-center justify-center rounded-md border border-dashed p-8">
            <div className="text-center text-muted-foreground">
              <p>No workout on selected date</p>
              <p className="text-sm">Select a date with a workout to view details</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
