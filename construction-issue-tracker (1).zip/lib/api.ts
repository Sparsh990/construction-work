// API client for interacting with the Flask backend

export async function loginUser(email: string, password: string) {
  try {
    const response = await fetch("http://localhost:5000/api/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Login failed")
    }

    const data = await response.json()
    // Store token in localStorage
    localStorage.setItem("boldfit_token", data.token)
    localStorage.setItem("boldfit_user", JSON.stringify(data.user))

    return data
  } catch (error) {
    console.error("Login error:", error)
    throw error
  }
}

export async function registerUser(email: string, password: string, name: string) {
  try {
    const response = await fetch("http://localhost:5000/api/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password, name }),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Registration failed")
    }

    return await response.json()
  } catch (error) {
    console.error("Registration error:", error)
    throw error
  }
}

export async function fetchDashboardData() {
  return fetchWithAuth("http://localhost:5000/api/fitness/dashboard")
}

export async function fetchFitnessData(dataType: string) {
  return fetchWithAuth(`http://localhost:5000/api/fitness/data/${dataType}`)
}

export async function addFitnessData(dataType: string, data: any) {
  return fetchWithAuth(`http://localhost:5000/api/fitness/data/${dataType}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
}

export async function updateGoals(goals: any) {
  return fetchWithAuth("http://localhost:5000/api/fitness/goals", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(goals),
  })
}

export async function getDietRecommendations() {
  return fetchWithAuth("http://localhost:5000/api/fitness/recommendations")
}

// Helper function to add auth token to requests
async function fetchWithAuth(url: string, options: RequestInit = {}) {
  const token = localStorage.getItem("boldfit_token")

  if (!token) {
    throw new Error("No authentication token found")
  }

  const authOptions = {
    ...options,
    headers: {
      ...options.headers,
      Authorization: `Bearer ${token}`,
    },
  }

  try {
    const response = await fetch(url, authOptions)

    if (!response.ok) {
      if (response.status === 401) {
        // Token expired or invalid
        localStorage.removeItem("boldfit_token")
        localStorage.removeItem("boldfit_user")
        throw new Error("Authentication expired. Please log in again.")
      }

      const error = await response.json()
      throw new Error(error.message || "API request failed")
    }

    return await response.json()
  } catch (error) {
    console.error("API request error:", error)
    throw error
  }
}
