"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Camera, MapPin, Upload } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

export default function NewIssuePage() {
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      toast({
        title: "Issue reported successfully",
        description: "Your issue has been submitted and assigned to the team.",
      })
    }, 1500)
  }

  return (
    <div className="flex min-h-screen w-full flex-col bg-slate-50">
      <header className="sticky top-0 z-10 border-b bg-white shadow-sm">
        <div className="container flex h-16 items-center py-4">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/dashboard">
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h1 className="text-lg font-semibold text-blue-800">Report New Issue</h1>
        </div>
      </header>
      <main className="flex-1">
        <div className="container max-w-3xl py-6">
          <Card className="border-blue-100 shadow-md">
            <form onSubmit={handleSubmit}>
              <CardHeader>
                <CardTitle className="text-xl text-blue-800">Issue Details</CardTitle>
                <CardDescription>Provide information about the construction issue you've encountered.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Issue Title</Label>
                  <Input id="title" placeholder="Brief description of the issue" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select required>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="safety">Safety Hazard</SelectItem>
                      <SelectItem value="material">Material Shortage</SelectItem>
                      <SelectItem value="equipment">Equipment Malfunction</SelectItem>
                      <SelectItem value="structural">Structural Issue</SelectItem>
                      <SelectItem value="electrical">Electrical Problem</SelectItem>
                      <SelectItem value="plumbing">Plumbing Issue</SelectItem>
                      <SelectItem value="water">Water Supply Problem</SelectItem>
                      <SelectItem value="wages">Wage Dispute</SelectItem>
                      <SelectItem value="workload">Excessive Workload</SelectItem>
                      <SelectItem value="facilities">Inadequate Facilities</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority">Priority Level</Label>
                  <RadioGroup defaultValue="medium" className="flex space-x-4">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="low" id="low" />
                      <Label htmlFor="low" className="font-normal">
                        Low
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="medium" id="medium" />
                      <Label htmlFor="medium" className="font-normal">
                        Medium
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="high" id="high" />
                      <Label htmlFor="high" className="font-normal">
                        High
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="critical" id="critical" />
                      <Label htmlFor="critical" className="font-normal">
                        Critical
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">Location on Site</Label>
                  <div className="flex space-x-2">
                    <Input id="location" placeholder="e.g., North Wing, 3rd Floor" className="flex-1" required />
                    <Button type="button" variant="outline" size="icon">
                      <MapPin className="h-4 w-4" />
                      <span className="sr-only">Select on map</span>
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Detailed Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Provide a detailed description of the issue, including any relevant context or observations."
                    rows={5}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Attach Photos/Documents</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <Button type="button" variant="outline" className="h-32 flex-col">
                      <Camera className="h-8 w-8 mb-2" />
                      <span>Take Photo</span>
                    </Button>
                    <Button type="button" variant="outline" className="h-32 flex-col">
                      <Upload className="h-8 w-8 mb-2" />
                      <span>Upload Files</span>
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="assignee">Assign To</Label>
                  <Select>
                    <SelectTrigger id="assignee">
                      <SelectValue placeholder="Select team member or leave unassigned" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unassigned">Unassigned</SelectItem>
                      <SelectItem value="team-lead">Team Lead</SelectItem>
                      <SelectItem value="site-manager">Site Manager</SelectItem>
                      <SelectItem value="electrical-team">Electrical Team</SelectItem>
                      <SelectItem value="plumbing-team">Plumbing Team</SelectItem>
                      <SelectItem value="safety-officer">Safety Officer</SelectItem>
                      <SelectItem value="hr-department">HR Department</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" asChild>
                  <Link href="/dashboard">Cancel</Link>
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={isSubmitting}>
                  {isSubmitting ? "Submitting..." : "Submit Issue"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </main>
    </div>
  )
}
