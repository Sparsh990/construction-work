"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Clock, MessageCircle, Paperclip, Send } from "lucide-react"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

export default function IssueDetailPage({ params }: { params: { id: string } }) {
  const { toast } = useToast()
  const [status, setStatus] = useState("in-progress")
  const [newComment, setNewComment] = useState("")

  const handleStatusChange = (value: string) => {
    setStatus(value)
    toast({
      title: "Status updated",
      description: `Issue status changed to ${value.replace("-", " ")}.`,
    })
  }

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (newComment.trim()) {
      toast({
        title: "Comment added",
        description: "Your comment has been added to the issue.",
      })
      setNewComment("")
    }
  }

  // Mock data for the issue
  const issue = {
    id: params.id,
    title: "Lack of drinking water in east wing work area",
    category: "Water Supply Problem",
    priority: "High",
    status: status,
    location: "East Wing, 2nd Floor, Main Work Area",
    createdBy: "John Carpenter",
    createdAt: "2 days ago",
    assignedTo: "Site Manager",
    description:
      "Workers in the east wing have no access to clean drinking water for the past 3 days. The nearest water station is on the ground floor, which is a 10-minute walk from the work area. This is causing dehydration issues, especially with the current high temperatures. We need water coolers installed on each floor or a more accessible water supply solution.",
    updates: [
      {
        id: 1,
        user: "Sarah Johnson",
        role: "Site Manager",
        time: "Yesterday at 3:45 PM",
        content:
          "I've inspected the area and confirmed the issue. We'll arrange for temporary water coolers to be delivered by tomorrow morning.",
        isUpdate: true,
      },
      {
        id: 2,
        user: "Mike Rodriguez",
        role: "Health & Safety Officer",
        time: "Yesterday at 4:30 PM",
        content:
          "This is a serious health concern. Please ensure that adequate water supply is available immediately. I'll follow up with a site inspection tomorrow.",
        isUpdate: false,
      },
      {
        id: 3,
        user: "John Carpenter",
        role: "Construction Worker",
        time: "Yesterday at 5:15 PM",
        content:
          "Thank you for the quick response. Several workers have been bringing their own water, but it's not sufficient for a full day's work in this heat.",
        isUpdate: false,
      },
      {
        id: 4,
        user: "Sarah Johnson",
        role: "Site Manager",
        time: "Today at 10:30 AM",
        content:
          "Update: Water coolers have been delivered to each floor of the east wing. We're also looking into a permanent solution with plumbed water stations. Please let me know if there are any further issues.",
        isUpdate: true,
      },
    ],
  }

  return (
    <div className="flex min-h-screen w-full flex-col bg-slate-50">
      <header className="sticky top-0 z-10 border-b bg-white shadow-sm">
        <div className="container flex h-16 items-center py-4">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/dashboard">
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h1 className="text-lg font-semibold text-blue-800">Issue #{issue.id}</h1>
        </div>
      </header>
      <main className="flex-1">
        <div className="container py-6">
          <div className="grid gap-6 md:grid-cols-3">
            <div className="md:col-span-2">
              <Card className="border-blue-100 shadow-md">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-xl text-blue-800">{issue.title}</CardTitle>
                      <CardDescription className="mt-1">
                        Reported by {issue.createdBy} • {issue.createdAt}
                      </CardDescription>
                    </div>
                    <Badge
                      className={
                        status === "open" ? "bg-red-500" : status === "in-progress" ? "bg-amber-500" : "bg-green-500"
                      }
                    >
                      {status.replace("-", " ")}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium text-blue-800">Description</h3>
                      <p className="mt-1 text-sm text-muted-foreground">{issue.description}</p>
                    </div>

                    <div className="grid gap-4 sm:grid-cols-2">
                      <div>
                        <h3 className="text-sm font-medium text-blue-800">Category</h3>
                        <p className="text-sm text-muted-foreground">{issue.category}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-blue-800">Priority</h3>
                        <p className="text-sm text-muted-foreground">{issue.priority}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-blue-800">Location</h3>
                        <p className="text-sm text-muted-foreground">{issue.location}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-blue-800">Assigned To</h3>
                        <p className="text-sm text-muted-foreground">{issue.assignedTo}</p>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-medium text-blue-800">Attachments</h3>
                      <div className="mt-2 grid grid-cols-3 gap-2">
                        {[1, 2, 3].map((i) => (
                          <div key={i} className="aspect-video rounded-md bg-muted" />
                        ))}
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-blue-800">Updates & Comments</h3>
                        <Button variant="ghost" size="sm">
                          <Clock className="mr-2 h-4 w-4" />
                          <span>Activity Log</span>
                        </Button>
                      </div>

                      <div className="mt-4 space-y-4">
                        {issue.updates.map((update) => (
                          <div key={update.id} className="flex gap-4">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={update.user} />
                              <AvatarFallback>
                                {update.user
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="font-medium">{update.user}</span>
                                <span className="text-xs text-muted-foreground">{update.role}</span>
                              </div>
                              <p className="text-sm">{update.content}</p>
                              <div className="flex items-center gap-4">
                                <span className="text-xs text-muted-foreground">{update.time}</span>
                                {update.isUpdate && (
                                  <Badge variant="outline" className="text-xs">
                                    Status Update
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <form onSubmit={handleCommentSubmit} className="w-full">
                    <div className="flex items-end gap-2">
                      <div className="flex-1">
                        <Label htmlFor="comment" className="sr-only">
                          Add comment
                        </Label>
                        <Textarea
                          id="comment"
                          placeholder="Add a comment or update..."
                          value={newComment}
                          onChange={(e) => setNewComment(e.target.value)}
                          className="min-h-[80px]"
                        />
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button type="button" variant="outline" size="icon">
                          <Paperclip className="h-4 w-4" />
                          <span className="sr-only">Attach file</span>
                        </Button>
                        <Button
                          type="submit"
                          size="icon"
                          className="bg-blue-600 hover:bg-blue-700"
                          disabled={!newComment.trim()}
                        >
                          <Send className="h-4 w-4" />
                          <span className="sr-only">Send</span>
                        </Button>
                      </div>
                    </div>
                  </form>
                </CardFooter>
              </Card>
            </div>

            <div>
              <Card className="border-blue-100 shadow-md">
                <CardHeader>
                  <CardTitle className="text-blue-800">Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="status">Update Status</Label>
                    <Select value={status} onValueChange={handleStatusChange}>
                      <SelectTrigger id="status">
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open">Open</SelectItem>
                        <SelectItem value="in-progress">In Progress</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reassign">Reassign Issue</Label>
                    <Select defaultValue="site-manager">
                      <SelectTrigger id="reassign">
                        <SelectValue placeholder="Select assignee" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="unassigned">Unassigned</SelectItem>
                        <SelectItem value="team-lead">Team Lead</SelectItem>
                        <SelectItem value="site-manager">Site Manager</SelectItem>
                        <SelectItem value="electrical-team">Electrical Team</SelectItem>
                        <SelectItem value="plumbing-team">Plumbing Team</SelectItem>
                        <SelectItem value="safety-officer">Safety Officer</SelectItem>
                        <SelectItem value="hr-department">HR Department</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-blue-800">Quick Actions</h3>
                    <div className="grid gap-2">
                      <Button variant="outline" className="justify-start">
                        <MessageCircle className="mr-2 h-4 w-4" />
                        <span>Request Update</span>
                      </Button>
                      <Button variant="outline" className="justify-start">
                        <Paperclip className="mr-2 h-4 w-4" />
                        <span>Add Attachment</span>
                      </Button>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-blue-800">Related Issues</h3>
                    <div className="space-y-2">
                      {[1, 2].map((i) => (
                        <Card key={i} className="p-3 border-blue-50">
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-xs text-muted-foreground">Issue #{i + 100}</span>
                              <Badge variant="outline" className="text-xs">
                                {i === 1 ? "In Progress" : "Open"}
                              </Badge>
                            </div>
                            <p className="text-sm font-medium">
                              {i === 1 ? "Inadequate restroom facilities" : "Excessive heat in work area"}
                            </p>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
