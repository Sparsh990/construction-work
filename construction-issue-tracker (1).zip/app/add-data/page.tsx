"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Calendar } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"

export default function AddDataPage() {
  const { toast } = useToast()
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [activeTab, setActiveTab] = useState("steps")

  // Form states
  const [steps, setSteps] = useState("")
  const [heartRate, setHeartRate] = useState("")
  const [calories, setCalories] = useState("")
  const [workoutType, setWorkoutType] = useState("")
  const [workoutDuration, setWorkoutDuration] = useState("")
  const [workoutIntensity, setWorkoutIntensity] = useState("medium")
  const [workoutNotes, setWorkoutNotes] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)

      let successMessage = ""
      if (activeTab === "steps") {
        successMessage = `${steps} steps recorded for ${format(date || new Date(), "PP")}`
      } else if (activeTab === "heart-rate") {
        successMessage = `Heart rate of ${heartRate} BPM recorded`
      } else if (activeTab === "calories") {
        successMessage = `${calories} calories recorded`
      } else if (activeTab === "workout") {
        successMessage = `${workoutType} workout recorded (${workoutDuration} minutes)`
      }

      toast({
        title: "Data saved successfully",
        description: successMessage,
      })

      // Reset form
      if (activeTab === "steps") setSteps("")
      else if (activeTab === "heart-rate") setHeartRate("")
      else if (activeTab === "calories") setCalories("")
      else if (activeTab === "workout") {
        setWorkoutType("")
        setWorkoutDuration("")
        setWorkoutIntensity("medium")
        setWorkoutNotes("")
      }
    }, 1000)
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <header className="sticky top-0 z-10 border-b bg-background">
        <div className="container flex h-16 items-center py-4">
          <Button variant="ghost" size="icon" onClick={() => router.push("/")} className="mr-2">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back</span>
          </Button>
          <h1 className="text-lg font-semibold">Add Fitness Data</h1>
        </div>
      </header>
      <main className="flex-1">
        <div className="container max-w-3xl py-6">
          <Card>
            <form onSubmit={handleSubmit}>
              <CardHeader>
                <CardTitle>Record New Data</CardTitle>
                <CardDescription>Add your fitness metrics to track your progress over time.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                      >
                        <Calendar className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <CalendarComponent mode="single" selected={date} onSelect={setDate} initialFocus />
                    </PopoverContent>
                  </Popover>
                </div>

                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="steps">Steps</TabsTrigger>
                    <TabsTrigger value="heart-rate">Heart Rate</TabsTrigger>
                    <TabsTrigger value="calories">Calories</TabsTrigger>
                    <TabsTrigger value="workout">Workout</TabsTrigger>
                  </TabsList>

                  <TabsContent value="steps" className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="steps">Step Count</Label>
                      <Input
                        id="steps"
                        type="number"
                        placeholder="e.g., 8000"
                        value={steps}
                        onChange={(e) => setSteps(e.target.value)}
                        required
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="heart-rate" className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="heart-rate">Heart Rate (BPM)</Label>
                      <Input
                        id="heart-rate"
                        type="number"
                        placeholder="e.g., 72"
                        value={heartRate}
                        onChange={(e) => setHeartRate(e.target.value)}
                        required
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="calories" className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="calories">Calories Burned</Label>
                      <Input
                        id="calories"
                        type="number"
                        placeholder="e.g., 1800"
                        value={calories}
                        onChange={(e) => setCalories(e.target.value)}
                        required
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="workout" className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="workout-type">Workout Type</Label>
                      <Select value={workoutType} onValueChange={setWorkoutType} required>
                        <SelectTrigger id="workout-type">
                          <SelectValue placeholder="Select workout type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="strength">Strength Training</SelectItem>
                          <SelectItem value="cardio">Cardio</SelectItem>
                          <SelectItem value="cycling">Cycling</SelectItem>
                          <SelectItem value="swimming">Swimming</SelectItem>
                          <SelectItem value="yoga">Yoga/Flexibility</SelectItem>
                          <SelectItem value="hiit">HIIT</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="workout-duration">Duration (minutes)</Label>
                      <Input
                        id="workout-duration"
                        type="number"
                        placeholder="e.g., 45"
                        value={workoutDuration}
                        onChange={(e) => setWorkoutDuration(e.target.value)}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Intensity Level</Label>
                      <RadioGroup defaultValue="medium" value={workoutIntensity} onValueChange={setWorkoutIntensity}>
                        <div className="flex space-x-4">
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="low" id="low" />
                            <Label htmlFor="low" className="font-normal">
                              Low
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="medium" id="medium" />
                            <Label htmlFor="medium" className="font-normal">
                              Medium
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="high" id="high" />
                            <Label htmlFor="high" className="font-normal">
                              High
                            </Label>
                          </div>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="workout-notes">Notes (optional)</Label>
                      <Textarea
                        id="workout-notes"
                        placeholder="Add any notes about your workout..."
                        value={workoutNotes}
                        onChange={(e) => setWorkoutNotes(e.target.value)}
                      />
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" type="button" onClick={() => router.push("/")}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? "Saving..." : "Save Data"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </main>
    </div>
  )
}
