"use client"

import { useState } from "react"
import Link from "next/link"
import { Bell, Filter, HardHat, Plus, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { IssuesList } from "@/components/issues-list"
import { IssueStats } from "@/components/issue-stats"
import { RecentActivity } from "@/components/recent-activity"
import { UserNav } from "@/components/user-nav"

export default function DashboardPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<"all" | "open" | "in-progress" | "resolved">("all")

  return (
    <div className="flex min-h-screen w-full flex-col">
      <header className="sticky top-0 z-10 border-b bg-white shadow-sm">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Link href="/dashboard" className="flex items-center text-xl font-bold text-blue-700">
              <HardHat className="mr-2 h-6 w-6" />
              <span>SiteConnect</span>
            </Link>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs text-white">
                3
              </span>
              <span className="sr-only">Notifications</span>
            </Button>
            <UserNav />
          </div>
        </div>
      </header>
      <main className="flex-1 bg-slate-50">
        <div className="container py-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-gray-900">Dashboard</h1>
              <p className="text-muted-foreground">Monitor and manage construction site issues in real-time.</p>
            </div>
            <div className="flex items-center gap-2">
              <Link href="/issues/new">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="mr-2 h-4 w-4" />
                  Report Issue
                </Button>
              </Link>
            </div>
          </div>

          <div className="mt-6">
            <IssueStats />
          </div>

          <div className="mt-6 grid gap-6 md:grid-cols-3">
            <div className="md:col-span-2">
              <Card className="border-blue-100 shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                  <div>
                    <CardTitle className="text-xl text-blue-800">Site Issues</CardTitle>
                    <CardDescription>View and manage reported issues across all construction sites.</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="relative w-full md:w-40 lg:w-64">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="search"
                        placeholder="Search issues..."
                        className="w-full pl-8"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    <Button variant="outline" size="icon">
                      <Filter className="h-4 w-4" />
                      <span className="sr-only">Filter</span>
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="all" onValueChange={(value) => setStatusFilter(value as any)}>
                    <TabsList className="grid w-full grid-cols-4">
                      <TabsTrigger value="all">All Issues</TabsTrigger>
                      <TabsTrigger value="open">Open</TabsTrigger>
                      <TabsTrigger value="in-progress">In Progress</TabsTrigger>
                      <TabsTrigger value="resolved">Resolved</TabsTrigger>
                    </TabsList>
                    <TabsContent value="all" className="mt-4">
                      <IssuesList filter="all" />
                    </TabsContent>
                    <TabsContent value="open" className="mt-4">
                      <IssuesList filter="open" />
                    </TabsContent>
                    <TabsContent value="in-progress" className="mt-4">
                      <IssuesList filter="in-progress" />
                    </TabsContent>
                    <TabsContent value="resolved" className="mt-4">
                      <IssuesList filter="resolved" />
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
            <div>
              <Card className="border-blue-100 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-blue-800">Recent Activity</CardTitle>
                  <CardDescription>Latest updates from your construction sites.</CardDescription>
                </CardHeader>
                <CardContent>
                  <RecentActivity />
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
