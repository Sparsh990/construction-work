import { NextResponse } from "next/server"

// Mock database for issues
const issues = [
  {
    id: "1234",
    title: "Lack of drinking water in east wing work area",
    location: "East Wing, 2nd Floor",
    category: "Water Supply Problem",
    priority: "High",
    status: "in-progress",
    reportedBy: "John Carpenter",
    reportedAt: "2023-04-19T10:30:00Z",
    assignedTo: "Site Manager",
    description:
      "Workers in the east wing have no access to clean drinking water for the past 3 days. The nearest water station is on the ground floor, which is a 10-minute walk from the work area. This is causing dehydration issues, especially with the current high temperatures. We need water coolers installed on each floor or a more accessible water supply solution.",
    updates: [
      {
        id: 1,
        user: "Sarah Johnson",
        role: "Site Manager",
        time: "2023-04-19T15:45:00Z",
        content:
          "I've inspected the area and confirmed the issue. We'll arrange for temporary water coolers to be delivered by tomorrow morning.",
        isUpdate: true,
      },
      {
        id: 2,
        user: "Mike Rodriguez",
        role: "Health & Safety Officer",
        time: "2023-04-19T16:30:00Z",
        content:
          "This is a serious health concern. Please ensure that adequate water supply is available immediately. I'll follow up with a site inspection tomorrow.",
        isUpdate: false,
      },
    ],
  },
  {
    id: "1235",
    title: "Excessive workload with insufficient breaks",
    location: "North Tower, All Floors",
    category: "Workload",
    priority: "Critical",
    status: "open",
    reportedBy: "Maria Rodriguez",
    reportedAt: "2023-04-20T09:15:00Z",
    assignedTo: "HR Department",
    description:
      "Workers on the North Tower project are being assigned excessive workloads without adequate breaks. Many are working 10+ hour shifts with only a single 30-minute break. This is leading to fatigue, decreased productivity, and safety concerns. We need a proper break schedule implemented immediately.",
    updates: [],
  },
  {
    id: "1236",
    title: "Wage payment delayed for contract workers",
    location: "Company-wide",
    category: "Wages",
    priority: "High",
    status: "open",
    reportedBy: "David Kim",
    reportedAt: "2023-04-18T14:20:00Z",
    assignedTo: "Contractor",
    description:
      "Contract workers have not received their wages for the past two weeks. This is causing significant financial hardship for many workers who rely on regular payment. The contractor claims there are administrative delays, but this is unacceptable. We need immediate resolution and a commitment to regular payment schedules.",
    updates: [],
  },
]

export async function GET(request: Request) {
  const url = new URL(request.url)
  const id = url.searchParams.get("id")

  if (id) {
    const issue = issues.find((issue) => issue.id === id)
    if (!issue) {
      return NextResponse.json({ error: "Issue not found" }, { status: 404 })
    }
    return NextResponse.json(issue)
  }

  const status = url.searchParams.get("status")
  if (status) {
    const filteredIssues = issues.filter((issue) => issue.status === status)
    return NextResponse.json(filteredIssues)
  }

  return NextResponse.json(issues)
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate required fields
    if (!body.title || !body.category || !body.description) {
      return NextResponse.json(
        { error: "Missing required fields: title, category, and description are required" },
        { status: 400 },
      )
    }

    // Generate a new issue
    const newIssue = {
      id: Math.floor(Math.random() * 10000).toString(),
      title: body.title,
      location: body.location || "Not specified",
      category: body.category,
      priority: body.priority || "Medium",
      status: "open",
      reportedBy: body.reportedBy || "Anonymous",
      reportedAt: new Date().toISOString(),
      assignedTo: body.assignedTo || "Unassigned",
      description: body.description,
      updates: [],
    }

    // In a real app, we would save this to a database
    issues.push(newIssue)

    return NextResponse.json(newIssue, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create issue" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: "Issue ID is required" }, { status: 400 })
    }

    const issueIndex = issues.findIndex((issue) => issue.id === body.id)
    if (issueIndex === -1) {
      return NextResponse.json({ error: "Issue not found" }, { status: 404 })
    }

    // Update the issue
    const updatedIssue = {
      ...issues[issueIndex],
      ...body,
    }

    // In a real app, we would update this in a database
    issues[issueIndex] = updatedIssue

    return NextResponse.json(updatedIssue)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update issue" }, { status: 500 })
  }
}
