import { NextResponse } from "next/server"

// Mock database for comments
const comments = [
  {
    id: "1",
    issueId: "1234",
    user: "John Carpenter",
    role: "Construction Worker",
    content:
      "Thank you for the quick response. Several workers have been bringing their own water, but it's not sufficient for a full day's work in this heat.",
    createdAt: "2023-04-19T17:15:00Z",
    isUpdate: false,
  },
  {
    id: "2",
    issueId: "1234",
    user: "Sarah Johnson",
    role: "Site Manager",
    content:
      "Update: Water coolers have been delivered to each floor of the east wing. We're also looking into a permanent solution with plumbed water stations. Please let me know if there are any further issues.",
    createdAt: "2023-04-20T10:30:00Z",
    isUpdate: true,
  },
]

export async function GET(request: Request) {
  const url = new URL(request.url)
  const issueId = url.searchParams.get("issueId")

  if (!issueId) {
    return NextResponse.json({ error: "Issue ID is required" }, { status: 400 })
  }

  const issueComments = comments.filter((comment) => comment.issueId === issueId)
  return NextResponse.json(issueComments)
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate required fields
    if (!body.issueId || !body.user || !body.content) {
      return NextResponse.json(
        { error: "Missing required fields: issueId, user, and content are required" },
        { status: 400 },
      )
    }

    // Generate a new comment
    const newComment = {
      id: Math.floor(Math.random() * 10000).toString(),
      issueId: body.issueId,
      user: body.user,
      role: body.role || "User",
      content: body.content,
      createdAt: new Date().toISOString(),
      isUpdate: body.isUpdate || false,
    }

    // In a real app, we would save this to a database
    comments.push(newComment)

    return NextResponse.json(newComment, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create comment" }, { status: 500 })
  }
}
