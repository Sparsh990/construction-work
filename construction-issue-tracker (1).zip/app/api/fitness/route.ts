import { NextResponse } from "next/server"

// Mock database for fitness data
const fitnessData = {
  steps: [
    { date: "2023-04-15", count: 8249, goal: 10000 },
    { date: "2023-04-16", count: 7362, goal: 10000 },
    { date: "2023-04-17", count: 9541, goal: 10000 },
    { date: "2023-04-18", count: 6823, goal: 10000 },
    { date: "2023-04-19", count: 10247, goal: 10000 },
    { date: "2023-04-20", count: 7895, goal: 10000 },
    { date: "2023-04-21", count: 8249, goal: 10000 },
  ],
  heartRate: [
    { date: "2023-04-15", average: 72, min: 58, max: 142 },
    { date: "2023-04-16", average: 68, min: 55, max: 135 },
    { date: "2023-04-17", average: 70, min: 56, max: 150 },
    { date: "2023-04-18", average: 72, min: 57, max: 145 },
    { date: "2023-04-19", average: 71, min: 58, max: 148 },
    { date: "2023-04-20", average: 69, min: 56, max: 140 },
    { date: "2023-04-21", average: 72, min: 58, max: 146 },
  ],
  calories: [
    { date: "2023-04-15", burned: 1842, goal: 2500 },
    { date: "2023-04-16", burned: 1756, goal: 2500 },
    { date: "2023-04-17", burned: 2105, goal: 2500 },
    { date: "2023-04-18", burned: 1650, goal: 2500 },
    { date: "2023-04-19", burned: 2250, goal: 2500 },
    { date: "2023-04-20", burned: 1920, goal: 2500 },
    { date: "2023-04-21", burned: 1842, goal: 2500 },
  ],
  workouts: [
    { date: "2023-04-15", type: "Strength", duration: 45, calories: 320 },
    { date: "2023-04-16", type: "Cardio", duration: 30, calories: 280 },
    { date: "2023-04-17", type: "Rest", duration: 0, calories: 0 },
    { date: "2023-04-18", type: "Cycling", duration: 50, calories: 450 },
    { date: "2023-04-19", type: "Swimming", duration: 40, calories: 380 },
    { date: "2023-04-20", type: "Rest", duration: 0, calories: 0 },
    { date: "2023-04-21", type: "Strength", duration: 45, calories: 320 },
  ],
  weight: [
    { date: "2023-04-01", value: 82.5 },
    { date: "2023-04-08", value: 81.8 },
    { date: "2023-04-15", value: 80.9 },
    { date: "2023-04-21", value: 79.3 },
  ],
  goals: [
    {
      id: 1,
      name: "Weight Goal",
      target: "Lose 5kg",
      current: "3.2kg lost",
      progress: 64,
      dueDate: "2023-05-15",
      status: "on-track",
    },
    {
      id: 2,
      name: "Weekly Workouts",
      target: "5 workouts",
      current: "4 completed",
      progress: 80,
      dueDate: "2023-04-23",
      status: "on-track",
    },
    {
      id: 3,
      name: "Daily Steps",
      target: "10,000 steps",
      current: "8,249 steps",
      progress: 82,
      dueDate: "2023-04-21",
      status: "on-track",
    },
    {
      id: 4,
      name: "Water Intake",
      target: "2.5L daily",
      current: "1.8L consumed",
      progress: 72,
      dueDate: "2023-04-21",
      status: "at-risk",
    },
  ],
  nutrition: {
    macros: [
      { name: "Protein", current: 120, target: 150, unit: "g" },
      { name: "Carbs", current: 180, target: 200, unit: "g" },
      { name: "Fat", current: 55, target: 65, unit: "g" },
    ],
    recommendations: [
      {
        id: 1,
        title: "Increase protein intake",
        description: "Based on your workout intensity, we recommend adding more lean protein to your diet.",
      },
      {
        id: 2,
        title: "Add more leafy greens",
        description: "Your micronutrient profile shows you could benefit from more vitamins A and K.",
      },
      {
        id: 3,
        title: "Consider omega-3 supplements",
        description: "Your heart rate variability could improve with more omega-3 fatty acids.",
      },
    ],
  },
}

export async function GET(request: Request) {
  const url = new URL(request.url)
  const dataType = url.searchParams.get("type")

  if (!dataType) {
    return NextResponse.json(fitnessData)
  }

  if (dataType === "steps") {
    return NextResponse.json(fitnessData.steps)
  }

  if (dataType === "heart-rate") {
    return NextResponse.json(fitnessData.heartRate)
  }

  if (dataType === "calories") {
    return NextResponse.json(fitnessData.calories)
  }

  if (dataType === "workouts") {
    return NextResponse.json(fitnessData.workouts)
  }

  if (dataType === "weight") {
    return NextResponse.json(fitnessData.weight)
  }

  if (dataType === "goals") {
    return NextResponse.json(fitnessData.goals)
  }

  if (dataType === "nutrition") {
    return NextResponse.json(fitnessData.nutrition)
  }

  return NextResponse.json({ error: "Invalid data type requested" }, { status: 400 })
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // In a real application, this would validate and store the data
    // For this example, we'll just return a success response

    return NextResponse.json({
      success: true,
      message: "Data saved successfully",
      data: body,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        message: "Failed to save data",
      },
      { status: 400 },
    )
  }
}
