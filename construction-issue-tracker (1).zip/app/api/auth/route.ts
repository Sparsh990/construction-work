import { NextResponse } from "next/server"

// Mock user database
const users = [
  {
    id: "1",
    name: "John Doe",
    email: "john.doe@example.com",
    password: "password123", // In a real app, this would be hashed
    role: "worker",
    site: "downtown-tower",
    jobTitle: "Carpenter",
  },
  {
    id: "2",
    name: "Jane Smith",
    email: "jane.smith@example.com",
    password: "password123",
    role: "contractor",
    site: "downtown-tower",
    company: "Smith Construction",
  },
  {
    id: "3",
    name: "Admin User",
    email: "admin@example.com",
    password: "admin123",
    role: "admin",
  },
]

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Check if it's a login or register request
    if (body.action === "login") {
      const { email, password } = body

      if (!email || !password) {
        return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
      }

      const user = users.find((u) => u.email === email && u.password === password)

      if (!user) {
        return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
      }

      // In a real app, we would generate a JWT token here
      const token = "mock-jwt-token"

      // Return user info without password
      const { password: _, ...userWithoutPassword } = user

      return NextResponse.json({
        user: userWithoutPassword,
        token,
      })
    } else if (body.action === "register") {
      const { name, email, password, role, site } = body

      if (!name || !email || !password || !role) {
        return NextResponse.json({ error: "Name, email, password, and role are required" }, { status: 400 })
      }

      // Check if user already exists
      if (users.some((u) => u.email === email)) {
        return NextResponse.json({ error: "User with this email already exists" }, { status: 409 })
      }

      // Create new user
      const newUser = {
        id: (users.length + 1).toString(),
        name,
        email,
        password, // In a real app, this would be hashed
        role,
        site,
        ...(body.jobTitle && { jobTitle: body.jobTitle }),
        ...(body.company && { company: body.company }),
      }

      // In a real app, we would save this to a database
      users.push(newUser)

      // Return success message
      return NextResponse.json({ message: "User registered successfully" }, { status: 201 })
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 })
  } catch (error) {
    return NextResponse.json({ error: "Authentication failed" }, { status: 500 })
  }
}
