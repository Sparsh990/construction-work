import numpy as np
from datetime import datetime, timedelta

class DietAnalyzer:
    """
    Analyzes user fitness data and provides diet recommendations
    """
    
    def __init__(self, user_data):
        self.user_data = user_data
        self.recent_workouts = self._get_recent_workouts(days=7)
        self.weight_trend = self._calculate_weight_trend()
        self.activity_level = self._calculate_activity_level()
        self.heart_metrics = self._analyze_heart_metrics()
    
    def _get_recent_workouts(self, days=7):
        """Get workout data from the last N days"""
        today = datetime.now()
        cutoff_date = (today - timedelta(days=days)).strftime('%Y-%m-%d')
        
        return [w for w in self.user_data['workouts'] if w['date'] >= cutoff_date]
    
    def _calculate_weight_trend(self):
        """Calculate weight change trend"""
        if len(self.user_data['weight']) < 2:
            return 0
        
        # Calculate average weekly change over available data
        weights = self.user_data['weight']
        if len(weights) >= 4:
            # Use linear regression for more accurate trend
            x = np.array(range(len(weights)))
            y = np.array([w['value'] for w in weights])
            slope, _ = np.polyfit(x, y, 1)
            return slope * 7  # Weekly change
        else:
            # Simple difference between last two measurements
            return weights[-1]['value'] - weights[-2]['value']
    
    def _calculate_activity_level(self):
        """Calculate overall activity level based on steps and workouts"""
        # Average daily steps
        recent_steps = self.user_data['steps'][-7:]
        avg_steps = sum(s['count'] for s in recent_steps) / len(recent_steps)
        
        # Workout intensity
        workout_minutes = sum(w['duration'] for w in self.recent_workouts if w['type'] != 'Rest')
        avg_workout_minutes = workout_minutes / 7  # Daily average
        
        # Combined activity score (simplified)
        activity_score = (avg_steps / 10000) * 0.6 + (avg_workout_minutes / 60) * 0.4
        
        if activity_score < 0.5:
            return "low"
        elif activity_score < 0.8:
            return "moderate"
        else:
            return "high"
    
    def _analyze_heart_metrics(self):
        """Analyze heart rate data for insights"""
        recent_hr = self.user_data['heart_rate'][-7:]
        
        if not recent_hr:
            return {"variability": "unknown", "resting": "unknown"}
        
        # Calculate heart rate variability
        hr_values = [hr['average'] for hr in recent_hr]
        hr_variability = max(hr_values) - min(hr_values)
        
        # Get average resting heart rate
        avg_resting_hr = sum(hr['min'] for hr in recent_hr) / len(recent_hr)
        
        variability_status = "normal"
        if hr_variability > 20:
            variability_status = "high"
        elif hr_variability < 10:
            variability_status = "low"
        
        resting_status = "normal"
        if avg_resting_hr > 75:
            resting_status = "elevated"
        elif avg_resting_hr < 55:
            resting_status = "athletic"
        
        return {
            "variability": variability_status,
            "resting": resting_status,
            "avg_resting_hr": avg_resting_hr,
            "variability_value": hr_variability
        }
    
    def generate_macro_recommendations(self):
        """Generate macronutrient recommendations based on user data"""
        # Base values (moderate activity, maintenance)
        protein_per_kg = 1.6  # g/kg of body weight
        carbs_per_kg = 4.0    # g/kg
        fat_per_kg = 1.0      # g/kg
        
        # Get current weight
        current_weight = self.user_data['weight'][-1]['value']
        
        # Adjust based on activity level
        if self.activity_level == "high":
            protein_per_kg += 0.4
            carbs_per_kg += 1.0
        elif self.activity_level == "low":
            protein_per_kg -= 0.2
            carbs_per_kg -= 1.0
        
        # Adjust based on weight trend (if trying to lose weight)
        if self.weight_trend > 0.2:  # Gaining weight
            carbs_per_kg -= 0.5
            fat_per_kg -= 0.1
        elif self.weight_trend < -0.5 and self.weight_trend > -1.0:  # Losing at good pace
            # Maintain current macros
            pass
        elif self.weight_trend < -1.0:  # Losing too fast
            carbs_per_kg += 0.5
            fat_per_kg += 0.1
        
        # Calculate recommended macros
        protein = round(protein_per_kg * current_weight)
        carbs = round(carbs_per_kg * current_weight)
        fat = round(fat_per_kg * current_weight)
        
        return {
            "protein": {"target": protein, "unit": "g"},
            "carbs": {"target": carbs, "unit": "g"},
            "fat": {"target": fat, "unit": "g"},
            "calories": {"target": round(protein * 4 + carbs * 4 + fat * 9), "unit": "kcal"}
        }
    
    def generate_diet_recommendations(self):
        """Generate specific diet recommendations based on user data"""
        recommendations = []
        
        # Recommendation based on activity level and weight goals
        if self.activity_level == "high" and self.weight_trend < 0:
            recommendations.append({
                "id": 1,
                "title": "Increase protein and carb intake",
                "description": "Your high activity level combined with weight loss suggests you need more fuel. Increase protein to support muscle recovery and carbs to maintain energy levels."
            })
        elif self.activity_level == "low" and self.weight_trend > 0:
            recommendations.append({
                "id": 1,
                "title": "Reduce carbohydrate intake",
                "description": "Your activity level is low while weight is increasing. Consider reducing carbs, especially refined sugars and processed foods."
            })
        else:
            recommendations.append({
                "id": 1,
                "title": "Maintain balanced macros",
                "description": "Your activity and weight trends suggest your current diet is well-balanced. Focus on food quality and meal timing."
            })
        
        # Recommendation based on heart metrics
        if self.heart_metrics["resting"] == "elevated":
            recommendations.append({
                "id": 2,
                "title": "Reduce sodium and increase potassium",
                "description": "Your elevated resting heart rate may benefit from reducing sodium intake and increasing potassium-rich foods like bananas, potatoes, and leafy greens."
            })
        elif self.heart_metrics["variability"] == "low":
            recommendations.append({
                "id": 2,
                "title": "Add more omega-3 fatty acids",
                "description": "Your heart rate variability is low. Consider adding more fatty fish, flaxseeds, or walnuts to your diet for omega-3 benefits."
            })
        else:
            recommendations.append({
                "id": 2,
                "title": "Add more leafy greens",
                "description": "Your micronutrient profile could benefit from more vitamins A and K found in leafy greens like kale, spinach, and collards."
            })
        
        # General recommendation based on workout patterns
        workout_types = [w["type"] for w in self.recent_workouts if w["type"] != "Rest"]
        if "Strength" in workout_types and workout_types.count("Strength") >= 3:
            recommendations.append({
                "id": 3,
                "title": "Time protein intake around workouts",
                "description": "With your frequent strength training, consume 20-30g of protein within 30 minutes after workouts to optimize muscle recovery."
            })
        elif "Cardio" in workout_types and workout_types.count("Cardio") >= 3:
            recommendations.append({
                "id": 3,
                "title": "Focus on post-workout carb replenishment",
                "description": "Your cardio-heavy routine requires glycogen replenishment. Consume easily digestible carbs within 30 minutes after longer sessions."
            })
        else:
            recommendations.append({
                "id": 3,
                "title": "Improve meal consistency",
                "description": "Your varied workout routine would benefit from consistent meal timing. Aim to eat every 3-4 hours to maintain energy levels."
            })
        
        return recommendations
    
    def generate_meal_plan(self):
        """Generate a sample meal plan based on user data and recommendations"""
        # This would be much more sophisticated in a real application
        # with a food database and personalized calculations
        
        meal_plan = {
            "breakfast": [],
            "lunch": [],
            "dinner": [],
            "snacks": []
        }
        
        # Add meal suggestions based on activity level and goals
        if self.activity_level == "high":
            meal_plan["breakfast"] = [
                "Egg white omelette with vegetables",
                "Oatmeal with berries and protein powder",
                "Greek yogurt with granola and honey"
            ]
            meal_plan["lunch"] = [
                "Grilled chicken salad with quinoa",
                "Turkey and avocado wrap with sweet potato",
                "Salmon with brown rice and vegetables"
            ]
            meal_plan["dinner"] = [
                "Lean steak with roasted vegetables",
                "Baked fish with sweet potato and broccoli",
                "Chicken stir-fry with brown rice"
            ]
            meal_plan["snacks"] = [
                "Protein shake with banana",
                "Greek yogurt with berries",
                "Apple with almond butter",
                "Protein bar"
            ]
        elif self.activity_level == "moderate":
            meal_plan["breakfast"] = [
                "Scrambled eggs with toast",
                "Smoothie with protein powder",
                "Overnight oats with fruit"
            ]
            meal_plan["lunch"] = [
                "Tuna salad sandwich",
                "Chicken and vegetable soup",
                "Quinoa bowl with vegetables and feta"
            ]
            meal_plan["dinner"] = [
                "Baked chicken with vegetables",
                "Fish tacos with avocado",
                "Tofu stir-fry with brown rice"
            ]
            meal_plan["snacks"] = [
                "Handful of nuts",
                "Apple with peanut butter",
                "Cottage cheese with fruit"
            ]
        else:  # low activity
            meal_plan["breakfast"] = [
                "Greek yogurt with berries",
                "Vegetable omelette",
                "Smoothie with greens and protein"
            ]
            meal_plan["lunch"] = [
                "Large salad with grilled chicken",
                "Vegetable soup with side salad",
                "Lettuce wraps with lean protein"
            ]
            meal_plan["dinner"] = [
                "Baked fish with steamed vegetables",
                "Zucchini noodles with turkey meatballs",
                "Cauliflower rice stir-fry"
            ]
            meal_plan["snacks"] = [
                "Celery with hummus",
                "Hard-boiled egg",
                "Small handful of nuts"
            ]
        
        return meal_plan
