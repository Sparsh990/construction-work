import numpy as np
from datetime import datetime, timedelta
from scipy import stats

class ProgressAnalyzer:
    """
    Analyzes user fitness data to track progress and provide insights
    """
    
    def __init__(self, user_data):
        self.user_data = user_data
    
    def analyze_steps_progress(self, days=30):
        """Analyze steps data to determine trends and progress"""
        steps_data = self.user_data['steps'][-days:]
        
        if not steps_data:
            return {"status": "insufficient_data"}
        
        # Extract step counts and dates
        dates = [datetime.strptime(s['date'], '%Y-%m-%d') for s in steps_data]
        counts = [s['count'] for s in steps_data]
        goals = [s['goal'] for s in steps_data]
        
        # Calculate basic statistics
        avg_steps = sum(counts) / len(counts)
        goal_achievement = sum(1 for c, g in zip(counts, goals) if c >= g) / len(counts)
        
        # Calculate trend using linear regression
        if len(counts) >= 7:
            x = np.array(range(len(counts)))
            y = np.array(counts)
            slope, _, r_value, p_value, _ = stats.linregress(x, y)
            
            trend_direction = "improving" if slope > 50 else "declining" if slope < -50 else "stable"
            trend_significance = "significant" if p_value < 0.05 else "not_significant"
        else:
            trend_direction = "unknown"
            trend_significance = "insufficient_data"
            slope = 0
        
        # Weekly averages
        weekly_averages = []
        if len(counts) >= 14:
            for i in range(0, len(counts), 7):
                if i + 7 <= len(counts):
                    weekly_avg = sum(counts[i:i+7]) / 7
                    weekly_averages.append({
                        "week": f"Week {i//7 + 1}",
                        "average": round(weekly_avg)
                    })
        
        return {
            "status": "success",
            "average_steps": round(avg_steps),
            "goal_achievement_rate": round(goal_achievement * 100, 1),
            "trend": {
                "direction": trend_direction,
                "significance": trend_significance,
                "slope": round(slope, 2)
            },
            "weekly_averages": weekly_averages,
            "insight": self._generate_steps_insight(avg_steps, goal_achievement, trend_direction)
        }
    
    def _generate_steps_insight(self, avg_steps, goal_achievement, trend):
        """Generate insight message based on steps analysis"""
        if avg_steps < 5000:
            base_message = "Your step count is below recommended levels for good health."
        elif avg_steps < 7500:
            base_message = "Your step count is moderate but could be improved for optimal health benefits."
        else:
            base_message = "Your step count is excellent and meets recommended guidelines for an active lifestyle."
        
        if goal_achievement < 0.3:
            achievement_message = "You're rarely meeting your daily step goal."
        elif goal_achievement < 0.7:
            achievement_message = "You're sometimes meeting your daily step goal."
        else:
            achievement_message = "You're consistently meeting your daily step goal."
        
        if trend == "improving":
            trend_message = "Your step count is trending upward, which is great progress!"
        elif trend == "declining":
            trend_message = "Your step count is trending downward. Consider finding ways to increase your daily activity."
        else:
            trend_message = "Your step count is stable."
        
        return f"{base_message} {achievement_message} {trend_message}"
    
    def analyze_weight_progress(self):
        """Analyze weight data to determine trends and progress"""
        weight_data = self.user_data['weight']
        
        if len(weight_data) < 2:
            return {"status": "insufficient_data"}
        
        # Extract weights and dates
        dates = [datetime.strptime(w['date'], '%Y-%m-%d') for w in weight_data]
        weights = [w['value'] for w in weight_data]
        
        # Calculate total change
        total_change = weights[-1] - weights[0]
        
        # Calculate weekly rate of change
        days_elapsed = (dates[-1] - dates[0]).days
        if days_elapsed < 7:
            weekly_rate = total_change * (7 / max(1, days_elapsed))
        else:
            weekly_rate = total_change * (7 / days_elapsed)
        
        # Calculate trend using linear regression
        x = np.array(range(len(weights)))
        y = np.array(weights)
        slope, _, r_value, p_value, _ = stats.linregress(x, y)
        
        # Adjust slope to weekly rate
        if len(dates) >= 2:
            avg_days_per_measurement = days_elapsed / (len(dates) - 1)
            slope_weekly = slope * (7 / avg_days_per_measurement)
        else:
            slope_weekly = 0
        
        # Determine if trend is healthy
        trend_health = "healthy"
        if abs(weekly_rate) > 1.0:
            trend_health = "too_fast"
        elif abs(weekly_rate) < 0.2 and abs(total_change) > 1.0:
            trend_health = "too_slow"
        
        # Generate insight
        if total_change < 0:
            direction = "losing"
            if trend_health == "healthy":
                insight = f"You're losing weight at a healthy rate of {abs(weekly_rate):.1f} kg per week."
            elif trend_health == "too_fast":
                insight = f"You're losing weight at {abs(weekly_rate):.1f} kg per week, which may be too fast. Consider increasing your caloric intake slightly."
            else:
                insight = f"You're losing weight at {abs(weekly_rate):.1f} kg per week. For more effective progress, consider adjusting your diet or exercise routine."
        elif total_change > 0:
            direction = "gaining"
            if trend_health == "healthy":
                insight = f"You're gaining weight at a controlled rate of {weekly_rate:.1f} kg per week."
            elif trend_health == "too_fast":
                insight = f"You're gaining weight at {weekly_rate:.1f} kg per week, which may be faster than ideal. Consider reviewing your diet."
            else:
                insight = f"You're gaining weight at {weekly_rate:.1f} kg per week. If this is muscle gain, this pace is appropriate."
        else:
            direction = "maintaining"
            insight = "Your weight has remained stable during this period."
        
        return {
            "status": "success",
            "total_change": round(total_change, 1),
            "weekly_rate": round(weekly_rate, 2),
            "trend": {
                "direction": direction,
                "health": trend_health,
                "significance": "significant" if p_value < 0.05 else "not_significant",
                "r_squared": round(r_value**2, 2)
            },
            "insight": insight
        }
    
    def analyze_workout_consistency(self, days=30):
        """Analyze workout consistency and patterns"""
        cutoff_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
        workouts = [w for w in self.user_data['workouts'] if w['date'] >= cutoff_date]
        
        if not workouts:
            return {"status": "insufficient_data"}
        
        # Count workout days
        workout_days = len([w for w in workouts if w['type'] != 'Rest'])
        total_days = min(days, len(workouts))
        consistency_rate = workout_days / total_days
        
        # Analyze workout types
        workout_types = {}
        for workout in workouts:
            if workout['type'] != 'Rest':
                workout_types[workout['type']] = workout_types.get(workout['type'], 0) + 1
        
        # Find most common workout type
        most_common_type = max(workout_types.items(), key=lambda x: x[1])[0] if workout_types else None
        
        # Calculate average duration
        durations = [w['duration'] for w in workouts if w['type'] != 'Rest']
        avg_duration = sum(durations) / len(durations) if durations else 0
        
        # Check for balanced routine
        is_balanced = len(workout_types) >= 3 and max(workout_types.values()) / sum(workout_types.values()) < 0.6
        
        # Generate insights
        if consistency_rate < 0.3:
            consistency_insight = "Your workout consistency is low. Aim for at least 3-4 workouts per week for optimal results."
        elif consistency_rate < 0.5:
            consistency_insight = "Your workout consistency is moderate. Try to maintain a more regular schedule for better results."
        else:
            consistency_insight = "Your workout consistency is excellent. Keep up the good work!"
        
        if is_balanced:
            balance_insight = "You have a well-balanced routine with good variety of workout types."
        else:
            balance_insight = f"Your routine is focused heavily on {most_common_type}. Consider adding more variety for balanced fitness."
        
        if avg_duration < 30:
            duration_insight = "Your workouts are relatively short. Consider extending some sessions for better endurance benefits."
        elif avg_duration > 60:
            duration_insight = "Your workouts are quite long. Ensure you're allowing adequate recovery between sessions."
        else:
            duration_insight = "Your workout duration is ideal for most fitness goals."
        
        return {
            "status": "success",
            "consistency_rate": round(consistency_rate * 100, 1),
            "workout_types": workout_types,
            "most_common_type": most_common_type,
            "average_duration": round(avg_duration),
            "is_balanced": is_balanced,
            "insights": {
                "consistency": consistency_insight,
                "balance": balance_insight,
                "duration": duration_insight
            }
        }
    
    def generate_progress_report(self):
        """Generate a comprehensive progress report"""
        steps_analysis = self.analyze_steps_progress()
        weight_analysis = self.analyze_weight_progress()
        workout_analysis = self.analyze_workout_consistency()
        
        # Overall progress score (simplified)
        progress_score = 0
        components = 0
        
        if steps_analysis["status"] == "success":
            steps_score = min(100, steps_analysis["goal_achievement_rate"])
            progress_score += steps_score
            components += 1
        
        if weight_analysis["status"] == "success":
            weight_score = 80 if weight_analysis["trend"]["health"] == "healthy" else 50
            progress_score += weight_score
            components += 1
        
        if workout_analysis["status"] == "success":
            workout_score = workout_analysis["consistency_rate"]
            progress_score += workout_score
            components += 1
        
        overall_score = round(progress_score / max(1, components))
        
        # Generate overall assessment
        if overall_score >= 80:
            assessment = "Excellent progress! You're consistently meeting your fitness goals and showing great commitment."
        elif overall_score >= 60:
            assessment = "Good progress. You're on the right track, but there's room for improvement in some areas."
        else:
            assessment = "You're making some progress, but there are several areas that need attention to reach your fitness goals."
        
        # Identify areas for improvement
        areas_for_improvement = []
        
        if steps_analysis["status"] == "success" and steps_analysis["goal_achievement_rate"] < 70:
            areas_for_improvement.append("Increase daily step count to meet your goals more consistently")
        
        if weight_analysis["status"] == "success" and weight_analysis["trend"]["health"] != "healthy":
            if weight_analysis["trend"]["health"] == "too_fast":
                areas_for_improvement.append("Adjust your diet to achieve a more sustainable rate of weight change")
            else:
                areas_for_improvement.append("Review your nutrition and exercise plan to make more effective progress toward your weight goals")
        
        if workout_analysis["status"] == "success":
            if workout_analysis["consistency_rate"] < 60:
                areas_for_improvement.append("Improve workout consistency by establishing a regular schedule")
            if not workout_analysis["is_balanced"]:
                areas_for_improvement.append("Add more variety to your workout routine for balanced fitness development")
        
        return {
            "overall_score": overall_score,
            "assessment": assessment,
            "areas_for_improvement": areas_for_improvement,
            "detailed_analysis": {
                "steps": steps_analysis,
                "weight": weight_analysis,
                "workouts": workout_analysis
            }
        }
