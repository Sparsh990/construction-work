from flask import Flask, request, jsonify
from flask_cors import CORS
import json
from datetime import datetime, timedelta
import random
import os
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
from functools import wraps

app = Flask(__name__)
CORS(app)

# In a real application, use a proper database
# For this example, we'll use simple JSON files
DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)

# Secret key for JWT
app.config['SECRET_KEY'] = 'bold_fit_secret_key'

# Helper functions
def get_user_data_path(user_id):
    return os.path.join(DATA_DIR, f"user_{user_id}.json")

def load_user_data(user_id):
    try:
        with open(get_user_data_path(user_id), 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return None

def save_user_data(user_id, data):
    with open(get_user_data_path(user_id), 'w') as f:
        json.dump(data, f, indent=2)

def load_users():
    try:
        with open(os.path.join(DATA_DIR, "users.json"), 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_users(users):
    with open(os.path.join(DATA_DIR, "users.json"), 'w') as f:
        json.dump(users, f, indent=2)

# JWT token required decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]
        
        if not token:
            return jsonify({'message': 'Token is missing'}), 401
        
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user_id = data['user_id']
        except:
            return jsonify({'message': 'Token is invalid'}), 401
        
        return f(current_user_id, *args, **kwargs)
    
    return decorated

# Routes
@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()
    
    if not data or not data.get('email') or not data.get('password'):
        return jsonify({'message': 'Missing required fields'}), 400
    
    users = load_users()
    
    if data['email'] in users:
        return jsonify({'message': 'User already exists'}), 400
    
    user_id = str(len(users) + 1)
    users[data['email']] = {
        'id': user_id,
        'email': data['email'],
        'password': generate_password_hash(data['password']),
        'name': data.get('name', 'User'),
        'created_at': datetime.now().isoformat()
    }
    
    save_users(users)
    
    # Create initial user data
    initial_data = generate_initial_fitness_data(user_id)
    save_user_data(user_id, initial_data)
    
    return jsonify({'message': 'User registered successfully'}), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    
    if not data or not data.get('email') or not data.get('password'):
        return jsonify({'message': 'Missing email or password'}), 400
    
    users = load_users()
    
    if data['email'] not in users:
        return jsonify({'message': 'Invalid credentials'}), 401
    
    user = users[data['email']]
    
    if check_password_hash(user['password'], data['password']):
        token = jwt.encode({
            'user_id': user['id'],
            'exp': datetime.utcnow() + timedelta(days=1)
        }, app.config['SECRET_KEY'], algorithm="HS256")
        
        return jsonify({
            'token': token,
            'user': {
                'id': user['id'],
                'email': user['email'],
                'name': user['name']
            }
        })
    
    return jsonify({'message': 'Invalid credentials'}), 401

@app.route('/api/fitness/dashboard', methods=['GET'])
@token_required
def get_dashboard(user_id):
    user_data = load_user_data(user_id)
    if not user_data:
        return jsonify({'message': 'User data not found'}), 404
    
    # Return a summary of the user's fitness data for the dashboard
    return jsonify({
        'steps': user_data['steps'][-7:],
        'heart_rate': user_data['heart_rate'][-7:],
        'calories': user_data['calories'][-7:],
        'workouts': user_data['workouts'][-5:],
        'weight': user_data['weight'][-4:],
        'goals': user_data['goals'],
        'nutrition': user_data['nutrition']
    })

@app.route('/api/fitness/data/<data_type>', methods=['GET'])
@token_required
def get_fitness_data(user_id, data_type):
    user_data = load_user_data(user_id)
    if not user_data:
        return jsonify({'message': 'User data not found'}), 404
    
    if data_type not in user_data:
        return jsonify({'message': f'Invalid data type: {data_type}'}), 400
    
    return jsonify(user_data[data_type])

@app.route('/api/fitness/data/<data_type>', methods=['POST'])
@token_required
def add_fitness_data(user_id, data_type):
    user_data = load_user_data(user_id)
    if not user_data:
        return jsonify({'message': 'User data not found'}), 404
    
    if data_type not in user_data:
        return jsonify({'message': f'Invalid data type: {data_type}'}), 400
    
    new_data = request.get_json()
    
    # Add timestamp if not provided
    if 'date' not in new_data:
        new_data['date'] = datetime.now().isoformat()
    
    user_data[data_type].append(new_data)
    save_user_data(user_id, user_data)
    
    # Update recommendations based on new data
    update_recommendations(user_id)
    
    return jsonify({'message': 'Data added successfully', 'data': new_data})

@app.route('/api/fitness/goals', methods=['POST'])
@token_required
def update_goals(user_id):
    user_data = load_user_data(user_id)
    if not user_data:
        return jsonify({'message': 'User data not found'}), 404
    
    new_goals = request.get_json()
    user_data['goals'] = new_goals
    save_user_data(user_id, user_data)
    
    return jsonify({'message': 'Goals updated successfully', 'goals': new_goals})

@app.route('/api/fitness/recommendations', methods=['GET'])
@token_required
def get_recommendations(user_id):
    user_data = load_user_data(user_id)
    if not user_data:
        return jsonify({'message': 'User data not found'}), 404
    
    return jsonify(user_data['nutrition']['recommendations'])

# Helper function to generate initial fitness data for a new user
def generate_initial_fitness_data(user_id):
    today = datetime.now()
    
    # Generate 30 days of historical data
    steps_data = []
    heart_rate_data = []
    calories_data = []
    workouts_data = []
    
    for i in range(30, 0, -1):
        date = (today - timedelta(days=i)).strftime('%Y-%m-%d')
        
        # Steps data
        steps = random.randint(5000, 12000)
        steps_data.append({
            'date': date,
            'count': steps,
            'goal': 10000
        })
        
        # Heart rate data
        avg_hr = random.randint(60, 75)
        heart_rate_data.append({
            'date': date,
            'average': avg_hr,
            'min': avg_hr - random.randint(5, 15),
            'max': avg_hr + random.randint(50, 80)
        })
        
        # Calories data
        calories = random.randint(1500, 2500)
        calories_data.append({
            'date': date,
            'burned': calories,
            'goal': 2500
        })
        
        # Workout data (not every day)
        if random.random() > 0.3:  # 70% chance of workout
            workout_types = ['Strength', 'Cardio', 'Cycling', 'Swimming', 'Yoga']
            workout_type = random.choice(workout_types)
            duration = random.randint(20, 60)
            workout_calories = duration * random.randint(7, 10)
            
            workouts_data.append({
                'date': date,
                'type': workout_type,
                'duration': duration,
                'calories': workout_calories
            })
        else:
            workouts_data.append({
                'date': date,
                'type': 'Rest',
                'duration': 0,
                'calories': 0
            })
    
    # Weight data (weekly)
    weight_data = []
    starting_weight = random.uniform(75.0, 85.0)
    
    for i in range(4, 0, -1):
        date = (today - timedelta(days=i*7)).strftime('%Y-%m-%d')
        weight = starting_weight - (4-i) * random.uniform(0.5, 1.0)
        weight_data.append({
            'date': date,
            'value': round(weight, 1)
        })
    
    # Goals
    goals = [
        {
            'id': 1,
            'name': 'Weight Goal',
            'target': 'Lose 5kg',
            'current': f'{round(starting_weight - weight_data[-1]["value"], 1)}kg lost',
            'progress': int(((starting_weight - weight_data[-1]["value"]) / 5) * 100),
            'dueDate': (today + timedelta(days=30)).strftime('%Y-%m-%d'),
            'status': 'on-track'
        },
        {
            'id': 2,
            'name': 'Weekly Workouts',
            'target': '5 workouts',
            'current': '4 completed',
            'progress': 80,
            'dueDate': (today + timedelta(days=7)).strftime('%Y-%m-%d'),
            'status': 'on-track'
        },
        {
            'id': 3,
            'name': 'Daily Steps',
            'target': '10,000 steps',
            'current': f'{steps_data[-1]["count"]} steps',
            'progress': int((steps_data[-1]["count"] / 10000) * 100),
            'dueDate': today.strftime('%Y-%m-%d'),
            'status': 'on-track' if steps_data[-1]["count"] >= 8000 else 'at-risk'
        },
        {
            'id': 4,
            'name': 'Water Intake',
            'target': '2.5L daily',
            'current': '1.8L consumed',
            'progress': 72,
            'dueDate': today.strftime('%Y-%m-%d'),
            'status': 'at-risk'
        }
    ]
    
    # Nutrition
    nutrition = {
        'macros': [
            {'name': 'Protein', 'current': 120, 'target': 150, 'unit': 'g'},
            {'name': 'Carbs', 'current': 180, 'target': 200, 'unit': 'g'},
            {'name': 'Fat', 'current': 55, 'target': 65, 'unit': 'g'}
        ],
        'recommendations': [
            {
                'id': 1,
                'title': 'Increase protein intake',
                'description': 'Based on your workout intensity, we recommend adding more lean protein to your diet.'
            },
            {
                'id': 2,
                'title': 'Add more leafy greens',
                'description': 'Your micronutrient profile shows you could benefit from more vitamins A and K.'
            },
            {
                'id': 3,
                'title': 'Consider omega-3 supplements',
                'description': 'Your heart rate variability could improve with more omega-3 fatty acids.'
            }
        ]
    }
    
    return {
        'user_id': user_id,
        'steps': steps_data,
        'heart_rate': heart_rate_data,
        'calories': calories_data,
        'workouts': workouts_data,
        'weight': weight_data,
        'goals': goals,
        'nutrition': nutrition
    }

def update_recommendations(user_id):
    """Update diet recommendations based on user's fitness data"""
    user_data = load_user_data(user_id)
    if not user_data:
        return
    
    # Analyze recent workout intensity
    recent_workouts = user_data['workouts'][-7:]
    workout_intensity = sum(w['duration'] for w in recent_workouts if w['type'] != 'Rest')
    
    # Analyze weight trend
    weight_trend = 0
    if len(user_data['weight']) >= 2:
        weight_trend = user_data['weight'][-1]['value'] - user_data['weight'][-2]['value']
    
    # Analyze heart rate variability (simplified)
    hr_variability = 0
    if len(user_data['heart_rate']) >= 7:
        hr_values = [hr['average'] for hr in user_data['heart_rate'][-7:]]
        hr_variability = max(hr_values) - min(hr_values)
    
    # Update recommendations based on analysis
    recommendations = []
    
    # Recommendation 1: Based on workout intensity
    if workout_intensity > 180:
        recommendations.append({
            'id': 1,
            'title': 'Increase protein intake',
            'description': 'Based on your high workout intensity, we recommend adding more lean protein to your diet.'
        })
    elif workout_intensity < 90:
        recommendations.append({
            'id': 1,
            'title': 'Reduce carbohydrate intake',
            'description': 'Your recent activity level is lower than usual. Consider reducing carbs slightly.'
        })
    else:
        recommendations.append({
            'id': 1,
            'title': 'Maintain balanced macros',
            'description': 'Your workout intensity is moderate. Keep a balanced intake of protein, carbs, and fats.'
        })
    
    # Recommendation 2: Based on weight trend
    if weight_trend > 0.5:
        recommendations.append({
            'id': 2,
            'title': 'Increase caloric deficit',
            'description': 'Your weight has increased recently. Consider reducing daily calories by 200-300.'
        })
    elif weight_trend < -1.0:
        recommendations.append({
            'id': 2,
            'title': 'Increase caloric intake',
            'description': 'You\'re losing weight faster than recommended. Consider adding 200-300 calories to your daily intake.'
        })
    else:
        recommendations.append({
            'id': 2,
            'title': 'Add more leafy greens',
            'description': 'Your micronutrient profile shows you could benefit from more vitamins A and K.'
        })
    
    # Recommendation 3: Based on heart rate variability
    if hr_variability > 20:
        recommendations.append({
            'id': 3,
            'title': 'Focus on recovery',
            'description': 'Your heart rate shows high variability. Consider adding more rest days and focus on sleep quality.'
        })
    else:
        recommendations.append({
            'id': 3,
            'title': 'Consider omega-3 supplements',
            'description': 'Your heart rate variability could improve with more omega-3 fatty acids.'
        })
    
    # Update user data with new recommendations
    user_data['nutrition']['recommendations'] = recommendations
    save_user_data(user_id, user_data)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
